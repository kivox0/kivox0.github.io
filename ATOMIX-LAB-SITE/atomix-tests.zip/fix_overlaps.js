/*
 * ATOMIX LAB · исправление накладок в структурных формулах.
 * Запуск: node fix_overlaps.js page.html page-fixed.html
 *
 * Что делает, простыми словами:
 *   1. Берёт все рисунки со страницы и ищет те же накладки, что check_overlaps.js.
 *   2. Если линия связи заходит на букву или знак заряда, конец этой линии
 *      отодвигается назад вдоль самой линии, пока между ней и символом
 *      не появится такой же просвет, как в правильных рисунках (≈0.7 ед.).
 *      Направление связи не меняется — линия просто становится чуть короче.
 *   3. У двойных и тройных связей соседние параллельные линии укорачиваются
 *      на ту же длину, чтобы связь осталась ровной.
 *   4. Новые рисунки записываются обратно в страницу на то же место.
 *      Всё остальное в файле не трогается.
 */
"use strict";
const fs = require("fs");
const { parseDrawing, checkDrawing, loadStructures } = require("./check_overlaps.js");

const GAP = 1.15;       // от оси линии до рамки символа: как у самых плотных правильных рисунков (≈0.55 ед. просвета)
const MIN_KEEP = 0.45;  // линия не должна стать короче 45% исходной длины
const PARALLEL = 0.05;  // |sin угла| между линиями двойной связи
const PARTNER_DIST = 8; // расстояние между линиями двойной/тройной связи, ед.

const inflate = (b, d) => ({ x0: b.x0 - d, x1: b.x1 + d, y0: b.y0 - d, y1: b.y1 + d });
const r1 = v => Math.round(v * 10) / 10;
const fmt = v => String(r1(v) === 0 ? 0 : r1(v));

// на каком участке [t0, t1] отрезок находится внутри прямоугольника (или null)
function clipT(s, b) {
  let t0 = 0, t1 = 1;
  const dx = s.x1 - s.x0, dy = s.y1 - s.y0;
  const p = [-dx, dx, -dy, dy], q = [s.x0 - b.x0, b.x1 - s.x0, s.y0 - b.y0, b.y1 - s.y0];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return null; continue; }
    const r = q[i] / p[i];
    if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; } else { if (r < t0) return null; if (r < t1) t1 = r; }
  }
  return [t0, t1];
}
const len = s => Math.hypot(s.x1 - s.x0, s.y1 - s.y0);

// разбор d в список отрезков с запоминанием, к какому <path> они относятся
function parsePaths(body) {
  const paths = [];
  const re = /<path\b([^>]*)\/>/g;
  let m;
  while ((m = re.exec(body))) {
    const d = /\sd='([^']*)'/.exec(m[1])[1];
    const tok = d.match(/[MLHVZ]|-?\d*\.?\d+(?:e-?\d+)?/gi) || [];
    const segs = [];
    let i = 0, cmd = "", x = 0, y = 0, sx = 0, sy = 0, newSub = false;
    const seg = (nx, ny) => { segs.push({ x0: x, y0: y, x1: nx, y1: ny, start: newSub }); newSub = false; x = nx; y = ny; };
    while (i < tok.length) {
      if (/[A-Z]/i.test(tok[i])) { cmd = tok[i].toUpperCase(); i++; if (cmd === "Z") seg(sx, sy); continue; }
      if (cmd === "M") { x = +tok[i]; y = +tok[i + 1]; sx = x; sy = y; i += 2; cmd = "L"; newSub = true; }
      else if (cmd === "L") { seg(+tok[i], +tok[i + 1]); i += 2; }
      else if (cmd === "H") { seg(+tok[i], y); i++; }
      else if (cmd === "V") { seg(x, +tok[i]); i++; }
      else i++;
    }
    paths.push({ tag: m[0], d, segs });
  }
  return paths;
}

// собрать d обратно: непрерывные участки — одной ломаной, горизонтали/вертикали — через H/V
function buildD(segs) {
  let out = "", cx = null, cy = null;
  for (const s of segs) {
    const x0 = r1(s.x0), y0 = r1(s.y0), x1 = r1(s.x1), y1 = r1(s.y1);
    if (cx !== x0 || cy !== y0) out += "M" + fmt(x0) + " " + fmt(y0);
    if (y1 === y0 && s.wasH) out += "H" + fmt(x1);
    else if (x1 === x0 && s.wasV) out += "V" + fmt(y1);
    else out += "L" + fmt(x1) + " " + fmt(y1);
    cx = x1; cy = y1;
  }
  return out;
}

function fixDrawing(body) {
  const { labels } = parseDrawing(body);
  const glyphs = labels.flatMap(L => L.glyphs);
  const paths = parsePaths(body);
  const all = paths.flatMap((p, pi) => p.segs.map((s, si) => Object.assign(s, { pi, si, orig: { ...s }, wasH: /H/.test(p.d), wasV: /V/.test(p.d) })));
  const log = [];

  // конец отрезка (0 — начало, 1 — конец), ближайший к рамке
  const nearEnd = (s, g) => {
    const cx = (g.x0 + g.x1) / 2, cy = (g.y0 + g.y1) / 2;
    return Math.hypot(s.x0 - cx, s.y0 - cy) <= Math.hypot(s.x1 - cx, s.y1 - cy) ? 0 : 1;
  };
  // укоротить отрезок с конца `end` на длину `cut`
  const shorten = (s, end, cut) => {
    const L = len(s), ux = (s.x1 - s.x0) / L, uy = (s.y1 - s.y0) / L;
    if (end === 0) { s.x0 += ux * cut; s.y0 += uy * cut; } else { s.x1 -= ux * cut; s.y1 -= uy * cut; }
  };
  // параллельные соседи (вторая и третья линии кратной связи)
  const partners = s => all.filter(o => {
    if (o === s) return false;
    const a = [s.x1 - s.x0, s.y1 - s.y0], b = [o.x1 - o.x0, o.y1 - o.y0];
    const la = Math.hypot(...a), lb = Math.hypot(...b);
    if (!la || !lb) return false;
    if (Math.abs((a[0] * b[1] - a[1] * b[0]) / (la * lb)) > PARALLEL) return false;
    // расстояние от середины соседа до прямой отрезка
    const mx = (o.x0 + o.x1) / 2 - s.x0, my = (o.y0 + o.y1) / 2 - s.y0;
    const dist = Math.abs(mx * a[1] - my * a[0]) / la;
    const proj = (mx * a[0] + my * a[1]) / la;
    return dist < PARTNER_DIST && proj > -2 && proj < la + 2;
  });

  for (let pass = 0; pass < 6; pass++) {
    let changed = false;
    for (const s of all) for (const g of glyphs) {
      const t = clipT(s, inflate(g, GAP));
      if (!t) continue;
      const L = len(s);
      const end = nearEnd(s, g);
      const cut = end === 0 ? t[1] * L : (1 - t[0]) * L;
      if (cut <= 0.01) continue;
      shorten(s, end, cut + 0.05);
      // тот же конец у параллельных линий кратной связи — на ту же длину
      // (если сосед заходит дальше нового конца — обрезаем его до того же уровня)
      const Ls = len(s), ux = (s.x1 - s.x0) / Ls, uy = (s.y1 - s.y0) / Ls;
      const px = end === 0 ? s.x0 : s.x1, py = end === 0 ? s.y0 : s.y1, dir = end === 0 ? -1 : 1;
      for (const o of partners(s)) {
        const oe = Math.hypot(o.x0 - px, o.y0 - py) < Math.hypot(o.x1 - px, o.y1 - py) ? 0 : 1;
        const qx = oe === 0 ? o.x0 : o.x1, qy = oe === 0 ? o.y0 : o.y1;
        const over = dir * ((qx - px) * ux + (qy - py) * uy);
        if (over > 0.05 && over < len(o)) shorten(o, oe, over);
      }
      log.push({ ch: g.ch, cut: +cut.toFixed(2) });
      changed = true;
    }
    if (!changed) break;
  }

  const short = all.filter(s => len(s) < MIN_KEEP * len(s.orig));
  let out = body;
  paths.forEach((p, pi) => {
    const segs = all.filter(s => s.pi === pi);
    if (!segs.some(s => s.x0 !== s.orig.x0 || s.y0 !== s.orig.y0 || s.x1 !== s.orig.x1 || s.y1 !== s.orig.y1)) return;
    out = out.replace(p.tag, p.tag.replace(`d='${p.d}'`, `d='${buildD(segs)}'`));
  });
  return { body: out, log, short: short.length };
}

function main() {
  const [inp, outp] = process.argv.slice(2);
  if (!inp || !outp) { console.error("node fix_overlaps.js page.html page-fixed.html"); process.exit(1); }
  const S = loadStructures(inp);
  let src = fs.readFileSync(inp, "utf8");
  const fixed = {}, report = [];
  for (const key of Object.keys(S)) for (const view of ["x", "s"]) {
    const g = S[key][view];
    if (!g) continue;
    const [w, h, body] = g;
    if (!checkDrawing(w, h, body).problems.length) continue;
    const r = fixDrawing(body);
    const left = checkDrawing(w, h, r.body).problems;
    report.push({ key, view, cuts: r.log.length, maxCut: Math.max(0, ...r.log.map(l => l.cut)), tooShort: r.short, left: left.length });
    const a = JSON.stringify(body), b = JSON.stringify(r.body);
    if (src.split(a).length !== 2) throw new Error("рисунок не найден однозначно: " + key + "/" + view);
    src = src.replace(a, () => b);
    (fixed[key] = fixed[key] || {})[view] = [w, h, r.body];
  }
  fs.writeFileSync(outp, src);
  fs.writeFileSync("fix_report.json", JSON.stringify(report, null, 1));
  const left = report.filter(r => r.left), short = report.filter(r => r.tooShort);
  console.log(`исправлено рисунков: ${report.length}; укорочено концов линий: ${report.reduce((a, r) => a + r.cuts, 0)}`);
  console.log(`самое большое укорачивание: ${Math.max(...report.map(r => r.maxCut)).toFixed(1)} ед.`);
  console.log(`осталось накладок: ${left.length}`, left.map(r => r.key + "/" + r.view).join(", "));
  console.log(`линий короче ${MIN_KEEP * 100}% исходной: ${short.length}`, short.map(r => r.key + "/" + r.view).join(", "));
}
main();
