"""
ATOMIX LAB · отрисовка подозрительных структурных формул (аналог tools/preview.py).
Запуск: python3 render.py [число рисунков] [--all]
Берёт overlaps.json (результат check_overlaps.js) и structures.json,
рисует каждый рисунок в Chromium со стилями страницы в двух видах:
слева — как его видит ученик, справа — с рамками, которые построил скрипт
(серые — все подписи, красные — подпись и линия, где найдена накладка).
Картинки: renders/NN_<вещество>_<вид>.png
"""
import json, sys, re, html, pathlib
from playwright.sync_api import sync_playwright

N = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 30
data = json.load(open("overlaps.json", encoding="utf-8"))
S = json.load(open("structures.json", encoding="utf-8"))
try:
    TRUTH = json.load(open("pixel_truth.json", encoding="utf-8"))
except FileNotFoundError:
    TRUTH = {}
out = pathlib.Path("renders"); out.mkdir(exist_ok=True)

CSS = """
body{margin:0;background:#fff;font-family:Arial,Helvetica,sans-serif;color:#12161d}
.card{display:inline-block;padding:14px 18px;background:#fff}
.title{font:600 14px Arial;margin:0 0 4px}.sub{font:12px Arial;color:#637082;margin:0 0 10px}
.row{display:flex;gap:28px;align-items:flex-start}
.pane{border:1px solid #dce0e7;border-radius:8px;padding:10px;background:#fff}
.cap{font:11px Arial;color:#637082;margin-top:6px}
.mol{display:block;height:auto;color:#12161d;fill:currentColor}
.mol path,.mol circle{fill:none;stroke:currentColor;stroke-width:1.2;stroke-linecap:round;stroke-linejoin:round}
.mol text{font:7pt Arial,Helvetica,sans-serif}.mol .nidx{font-size:7pt;font-style:italic}
.mol .o{fill:#c4321f}.mol .n{fill:#2446d8}.mol .x{fill:#1d7a49}
.dbg rect{fill:none;stroke:#8f98a6;stroke-width:.25}
.dbg rect.bad{stroke:#e0202a;stroke-width:.45;fill:rgba(224,32,42,.08)}
.dbg rect.mid{stroke:#e0202a;stroke-width:.3;stroke-dasharray:.8 .6}
.dbg line.bad{stroke:#e0202a;stroke-width:1.6;stroke-opacity:.55}
"""

def segments_of(body):
    segs = []
    for m in re.finditer(r"<path\b([^>]*)/>", body):
        d = re.search(r"d='([^']*)'", m.group(1)).group(1)
        tok = re.findall(r"[MLHVZ]|-?\d*\.?\d+", d)
        i, cmd, x, y = 0, "", 0, 0
        while i < len(tok):
            t = tok[i]
            if t.isalpha():
                cmd = t; i += 1; continue
            if cmd == "M": x, y = float(tok[i]), float(tok[i+1]); i += 2; cmd = "L"
            elif cmd == "L": nx, ny = float(tok[i]), float(tok[i+1]); segs.append((x, y, nx, ny)); x, y = nx, ny; i += 2
            elif cmd == "H": nx = float(tok[i]); segs.append((x, y, nx, y)); x = nx; i += 1
            elif cmd == "V": ny = float(tok[i]); segs.append((x, y, x, ny)); y = ny; i += 1
            else: i += 1
    return segs

def svg(w, h, body, scale, overlay=""):
    return (f'<svg class="mol" viewBox="0 0 {w} {h}" style="width:{w*scale}px" xmlns="http://www.w3.org/2000/svg">'
            f'{body}<g class="dbg">{overlay}</g></svg>')

def main():
    rows = data["bad"][:N]
    global GLYPHS
    import subprocess
    keys = json.dumps([[r["key"], r["view"]] for r in rows])
    GLYPHS = json.loads(subprocess.run(["node", "-e", """
const {parseDrawing}=require("./check_overlaps.js");const S=require("./structures.json");const out={};
for (const [k,v] of JSON.parse(process.argv[1])) out[k+"/"+v]=parseDrawing(S[k][v][2]).labels.flatMap(l=>l.glyphs.map(g=>[g.x0,g.y0,g.x1,g.y1].map(n=>+n.toFixed(2))));
console.log(JSON.stringify(out));""", keys], capture_output=True, text=True, check=True).stdout)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(device_scale_factor=2)
        for i, r in enumerate(rows, 1):
            w, h, body = S[r["key"]][r["view"]]
            segs = segments_of(body)
            # все рамки подписей из полного отчёта
            full = next(a for a in data["all"] if a["key"] == r["key"] and a["view"] == r["view"])
            ov = "".join(f'<rect x="{g[0]}" y="{g[1]}" width="{g[2]-g[0]}" height="{g[3]-g[1]}"/>' for g in GLYPHS[r["key"] + "/" + r["view"]])
            for pr in r["problems"]:
                x0, y0, x1, y1 = pr["box"]
                ov += f'<rect class="bad" x="{x0}" y="{y0}" width="{x1-x0}" height="{y1-y0}"/>'
                if pr["type"] == "bond":
                    cx, cy, hw, hh = (x0+x1)/2, (y0+y1)/2, (x1-x0)/4, (y1-y0)/4
                    ov += f'<rect class="mid" x="{cx-hw}" y="{cy-hh}" width="{2*hw}" height="{2*hh}"/>'
                if pr.get("box2"):
                    a0, b0, a1, b1 = pr["box2"]
                    ov += f'<rect class="bad" x="{a0}" y="{b0}" width="{a1-a0}" height="{b1-b0}"/>'
                if pr.get("seg") is not None:
                    s = segs[pr["seg"]]
                    ov += f'<line class="bad" x1="{s[0]}" y1="{s[1]}" x2="{s[2]}" y2="{s[3]}"/>'
            scale = max(3.0, min(6.0, 420 / w))
            RU = {"letter": "линия на букве", "charge": "линия на знаке заряда", "bracket": "скобка на букве", "label": "подписи друг на друге", "ring": "цикл на букве", "clip": "обрезано краем"}
            kinds = ", ".join(f"{RU[k]}: {r[k]}" for k in RU if r[k]) + f" · по пикселям: {TRUTH.get(r['key'] + '/' + r['view'], '—')} px"
            page = (f'<!doctype html><meta charset="utf-8"><style>{CSS}</style><div class="card" id="c">'
                    f'<p class="title">#{i} · {html.escape(r["key"])} · {"развёрнутая" if r["view"]=="x" else "скелетная"}</p>'
                    f'<p class="sub">найдено: {r["total"]} ({kinds})</p><div class="row">'
                    f'<div class="pane">{svg(w,h,body,scale)}<div class="cap">как на странице (×{scale:.1f})</div></div>'
                    f'<div class="pane">{svg(w,h,body,scale,ov)}<div class="cap">рамки скрипта: серые — символы, красные — символ, на который заходит выделенная линия</div></div>'
                    f'</div></div>')
            pg.set_content(page)
            name = re.sub(r"[^\w\-\[\]()^+·]", "_", r["key"])
            pg.locator("#c").screenshot(path=str(out / f'{i:02d}_{name}_{r["view"]}.png'))
        b.close()
    print("готово:", len(rows), "картинок в", out)

main()
