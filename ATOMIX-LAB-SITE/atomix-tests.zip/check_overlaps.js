#!/usr/bin/env node
/* ============================================================
   ATOMIX LAB · Тест 2: поиск визуальных накладок в структурных формулах
   Чистая геометрия, без браузера.

   Запуск:
     node check_overlaps.js page.html             — рисунки из <script id="chem-structures">
     node check_overlaps.js structures-out.json   — или из готового JSON
     node check_overlaps.js page.html --calibrate — сравнить с pixel_truth.json
                                                    (эталон из pixel_truth.py)
   Результат: таблица в консоли + overlaps.json с подробностями.

   Как устроена проверка
   ---------------------
   Каждая подпись (<text>) разбивается на отдельные символы. Для каждого символа
   строится рамка по его видимой части:
     • заглавная буква — от верха заглавных до базовой линии (0.72 кегля),
       строчная — высота строчных (0.52 кегля), у g/p/y ещё хвостик вниз;
     • нижний индекс (₂) — нижняя половина строки;
     • верхний индекс (⁺ ⁻ ² ³) — верхняя половина строки.
   Ширина символа — по таблице ширин Arial, по бокам снимаются «поля» символа.
   Затем проверяется:
     1. letter — линия связи или скобка заходит на букву глубже, чем на PEN единиц;
     2. charge — линия заходит на знак заряда (верхний индекс);
     3. label  — рамки двух РАЗНЫХ подписей пересекаются;
     4. ring   — окружность цикла проходит через букву;
     5. clip   — подпись выходит за границы рисунка и обрезается.
   Одна линия и одна подпись дают не больше одной проблемы каждого вида.
   ============================================================ */
"use strict";
const fs = require("fs");

/* ---------- настройки ---------- */
const FS = 7 * 96 / 72;   // кегль: .mol text { font: 7pt } = 9.333 единицы рисунка
const STROKE = 0.6;       // половина толщины линии (stroke-width: 1.2)
const PEN = 0.3;          // насколько линия должна «зайти» на символ, чтобы это было видно
const MIN_OVERLAP = 0.5;  // подписи перекрываются хотя бы на 0.5 ед. по обеим осям
const CLIP_TOL = 0.5;

/* ---------- загрузка рисунков ---------- */
function loadStructures(file) {
  const raw = fs.readFileSync(file, "utf8");
  if (/\.json$/i.test(file)) return JSON.parse(raw);
  const m = /<script id="chem-structures">([\s\S]*?)<\/script>/.exec(raw);
  if (!m) throw new Error('В файле нет <script id="chem-structures">');
  const window = { ATOMIX_CHEM_DATA: {} };
  new Function("window", m[1])(window);
  return window.ATOMIX_CHEM_DATA.structures;
}

/* ---------- метрики шрифта (доли кегля, по таблице ширин Arial) ---------- */
const W = {
  A: .667, B: .667, C: .722, D: .722, E: .667, F: .611, G: .778, H: .722, I: .278, J: .5, K: .667, L: .556, M: .833,
  N: .722, O: .778, P: .667, Q: .778, R: .722, S: .667, T: .611, U: .722, V: .667, W: .944, X: .667, Y: .667, Z: .611,
  a: .556, b: .556, c: .5, d: .556, e: .556, f: .278, g: .556, h: .556, i: .222, j: .222, k: .5, l: .222, m: .833,
  n: .556, o: .556, p: .556, q: .556, r: .333, s: .5, t: .278, u: .556, v: .5, w: .722, x: .5, y: .5, z: .5,
  "(": .333, ")": .333, "[": .278, "]": .278, " ": .278, "-": .333, "+": .584, "·": .278, ",": .278
};
const SUB = /[₀-₉]/, SUP = /[⁰¹²³⁴-⁹⁺⁻]/;
// у надстрочных и подстрочных символов Arial нет — браузер берёт их из запасного шрифта
function charW(c) {
  if (W[c] !== undefined) return W[c];
  if (/\d/.test(c)) return .556;
  if (SUB.test(c) || SUP.test(c)) return .42;
  return .6;
}
function textWidth(s) { let w = 0; for (const c of s) w += charW(c); return w * FS; }

// видимая часть символа по вертикали относительно базовой линии (вверх — минус)
function glyphV(c) {
  if (SUP.test(c)) return [-0.81, -0.36];              // верхняя половина строки
  if (SUB.test(c)) return [-0.36, 0.14];               // нижняя половина, чуть ниже базовой линии
  if (/[A-Z0-9bdfhklt()\[\]]/.test(c)) return [-0.72, 0]; // высота заглавных
  if (/[gpqy]/.test(c)) return [-0.52, 0.2];           // строчные с хвостиком вниз
  if (/[a-z]/.test(c)) return [-0.52, 0];              // строчные
  return [-0.5, 0];
}
// поля символа по бокам (доля ширины), у знаков заряда больше
function glyphInset(c) { return SUP.test(c) || SUB.test(c) ? 0.18 : /[IJilj1]/.test(c) ? 0.3 : /[AVWXYMvwxy]/.test(c) ? 0.01 : 0.08; }

/* ---------- разбор SVG ---------- */
function attr(tag, name) { const m = new RegExp("\\s" + name + "='([^']*)'").exec(tag); return m ? m[1] : null; }
function lenToUnits(v) { return v == null ? 0 : /em$/.test(v) ? parseFloat(v) * FS : parseFloat(v); }
function stripTags(s) { return s.replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">"); }

function parseDrawing(body) {
  const labels = [], segments = [], circles = [];
  const reText = /<text\b([^>]*)>([\s\S]*?)<\/text>/g;
  let m, id = 0;
  while ((m = reText.exec(body))) {
    const tag = m[1], inner = m[2];
    let tx = 0, ty = 0;
    const tr = /translate\(([-\d.]+)\s+([-\d.]+)\)/.exec(attr(tag, "transform") || "");
    if (tr) { tx = +tr[1]; ty = +tr[2]; }
    if (attr(tag, "x") != null) tx += lenToUnits(attr(tag, "x"));
    const anchor = attr(tag, "text-anchor") || "start";
    const central = attr(tag, "dominant-baseline") === "central";
    const ownY = attr(tag, "y");
    // строки подписи: tspan с координатой y — отдельная строка (C над H₂), иначе одна строка
    const lines = [];
    const reTs = /<tspan\b([^>]*\sy='[^']*'[^>]*)>([\s\S]*?)<\/tspan>/g;
    let t;
    while ((t = reTs.exec(inner))) lines.push({ text: stripTags(t[2]), dy: lenToUnits(attr(t[1], "y")) });
    if (!lines.length) lines.push({ text: stripTags(inner), dy: 0 });

    const glyphs = [], boxes = [];
    lines.filter(l => l.text.trim()).forEach(l => {
      const w = textWidth(l.text);
      // базовая линия: при central центр строки на y (центр = базовая − 0.36 кегля),
      // при y=".36em" базовая линия на 0.36 кегля ниже точки привязки
      const base = central ? ty + l.dy + 0.36 * FS : ty + lenToUnits(ownY);
      let x = anchor === "end" ? tx - w : anchor === "middle" ? tx - w / 2 : tx;
      const line = { x0: x, x1: x + w, y0: Infinity, y1: -Infinity };
      for (const c of l.text) {
        const cw = charW(c) * FS;
        if (c.trim()) {
          const v = glyphV(c), ins = glyphInset(c) * cw;
          const g = { x0: x + ins, x1: x + cw - ins, y0: base + v[0] * FS, y1: base + v[1] * FS, ch: c, sup: SUP.test(c) };
          glyphs.push(g);
          line.y0 = Math.min(line.y0, g.y0); line.y1 = Math.max(line.y1, g.y1);
        }
        x += cw;
      }
      boxes.push(line);
    });
    if (glyphs.length) labels.push({ id: id++, text: lines.map(l => l.text).join("/"), glyphs, boxes });
  }

  const rePath = /<path\b([^>]*)\/>/g;
  while ((m = rePath.exec(body))) {
    const d = attr(m[1], "d") || "", kind = attr(m[1], "class") === "br" ? "bracket" : "bond";
    const tok = d.match(/[MLHVZ]|-?\d*\.?\d+(?:e-?\d+)?/gi) || [];
    let i = 0, cmd = "", x = 0, y = 0, sx = 0, sy = 0;
    const seg = (nx, ny) => { segments.push({ x0: x, y0: y, x1: nx, y1: ny, kind }); x = nx; y = ny; };
    while (i < tok.length) {
      if (/[A-Z]/i.test(tok[i])) { cmd = tok[i].toUpperCase(); i++; if (cmd === "Z") seg(sx, sy); continue; }
      if (cmd === "M") { x = +tok[i]; y = +tok[i + 1]; sx = x; sy = y; i += 2; cmd = "L"; }
      else if (cmd === "L") { seg(+tok[i], +tok[i + 1]); i += 2; }
      else if (cmd === "H") { seg(+tok[i], y); i++; }
      else if (cmd === "V") { seg(x, +tok[i]); i++; }
      else i++;
    }
  }
  const reC = /<circle\b([^>]*)\/>/g;
  while ((m = reC.exec(body))) circles.push({ cx: +attr(m[1], "cx"), cy: +attr(m[1], "cy"), r: +attr(m[1], "r") });
  return { labels, segments, circles };
}

/* ---------- геометрия ---------- */
function inflate(b, d) { return { x0: b.x0 - d, x1: b.x1 + d, y0: b.y0 - d, y1: b.y1 + d }; }
// пересекает ли отрезок прямоугольник (отсечение Лианга — Барски)
function segHitsBox(s, b) {
  if (b.x1 < b.x0 || b.y1 < b.y0) return false;
  let t0 = 0, t1 = 1;
  const dx = s.x1 - s.x0, dy = s.y1 - s.y0;
  const p = [-dx, dx, -dy, dy], q = [s.x0 - b.x0, b.x1 - s.x0, s.y0 - b.y0, b.y1 - s.y0];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; continue; }
    const r = q[i] / p[i];
    if (p[i] < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
  }
  return true;
}
function overlap(a, b) {
  const w = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0), h = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0);
  return w > 0 && h > 0 ? { w, h, area: w * h } : null;
}
function circleCrossesBox(c, b) {
  const nx = Math.max(b.x0, Math.min(c.cx, b.x1)), ny = Math.max(b.y0, Math.min(c.cy, b.y1));
  const dmin = Math.hypot(c.cx - nx, c.cy - ny);
  const dmax = Math.max(...[[b.x0, b.y0], [b.x1, b.y0], [b.x0, b.y1], [b.x1, b.y1]].map(p => Math.hypot(c.cx - p[0], c.cy - p[1])));
  return dmin <= c.r && c.r <= dmax;
}
const r1 = v => +v.toFixed(1);
const boxArr = b => [b.x0, b.y0, b.x1, b.y1].map(r1);

function checkDrawing(width, height, body, pen) {
  if (pen === undefined) pen = PEN;
  const { labels, segments, circles } = parseDrawing(body);
  const problems = [];
  labels.forEach(L => {
    segments.forEach((s, si) => {
      let hitLetter = null, hitSign = null;
      for (const g of L.glyphs) {
        if (!segHitsBox(s, inflate(g, STROKE - pen))) continue;
        if (g.sup) hitSign = hitSign || g; else hitLetter = hitLetter || g;
      }
      if (hitLetter) problems.push({ type: s.kind === "bracket" ? "bracket" : "letter", label: L.text, ch: hitLetter.ch, seg: si, box: boxArr(hitLetter) });
      if (hitSign) problems.push({ type: "charge", label: L.text, ch: hitSign.ch, seg: si, box: boxArr(hitSign) });
    });
    circles.forEach((c, ci) => {
      const g = L.glyphs.find(g => !g.sup && circleCrossesBox(c, inflate(g, STROKE - pen)));
      if (g) problems.push({ type: "ring", label: L.text, ch: g.ch, circle: ci, box: boxArr(g) });
    });
    L.boxes.forEach(b => {
      if (b.x0 < -CLIP_TOL || b.y0 < -CLIP_TOL || b.x1 > width + CLIP_TOL || b.y1 > height + CLIP_TOL)
        problems.push({ type: "clip", label: L.text, box: boxArr(b), by: r1(Math.max(-b.x0, -b.y0, b.x1 - width, b.y1 - height)) });
    });
  });
  for (let i = 0; i < labels.length; i++) for (let j = i + 1; j < labels.length; j++) {
    let found = null;
    for (const a of labels[i].boxes) for (const b of labels[j].boxes) {
      const o = overlap(a, b);
      if (o && o.w > MIN_OVERLAP && o.h > MIN_OVERLAP && !found) found = { a, b, o };
    }
    if (found) problems.push({ type: "label", label: labels[i].text + " ↔ " + labels[j].text, area: r1(found.o.area), box: boxArr(found.a), box2: boxArr(found.b) });
  }
  return { labels, segments, circles, problems };
}

/* ---------- запуск ---------- */
const TYPES = ["letter", "charge", "bracket", "label", "ring", "clip"];
function runAll(S, pen) {
  const report = [];
  Object.keys(S).forEach(key => ["x", "s"].forEach(view => {
    const g = S[key][view];
    if (!g) return;
    const r = checkDrawing(g[0], g[1], g[2], pen);
    const row = { key, view, w: g[0], h: g[1], total: r.problems.length, problems: r.problems };
    TYPES.forEach(t => { row[t] = r.problems.filter(p => p.type === t).length; });
    report.push(row);
  }));
  return report;
}

function main() {
  const file = process.argv[2] || "page.html";
  const S = loadStructures(file);

  if (process.argv.includes("--calibrate")) {
    // сверка с эталоном по пикселям: какой допуск PEN лучше всего совпадает с реальными перекрытиями
    const truth = JSON.parse(fs.readFileSync("pixel_truth.json", "utf8"));
    const TH = 3; // столько тёмных пикселей при ×4 (≈0.2 ед.²) считаем видимой накладкой
    console.log("PEN   совпало  лишних  пропущено  (эталон: рисунков с перекрытием ≥" + TH + " px)");
    [0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5].forEach(pen => {
      const rep = runAll(S, pen);
      let tp = 0, fp = 0, fn = 0;
      rep.forEach(r => {
        const geo = r.letter + r.charge + r.bracket + r.ring > 0, pix = (truth[r.key + "/" + r.view] || 0) >= TH;
        if (geo && pix) tp++; else if (geo) fp++; else if (pix) fn++;
      });
      console.log(String(pen).padEnd(6), String(tp).padStart(6), String(fp).padStart(7), String(fn).padStart(10));
    });
    return;
  }

  const report = runAll(S, PEN);
  const weight = r => r.letter + r.charge + r.bracket + r.ring + r.label + r.clip;
  const bad = report.filter(r => r.total > 0).sort((a, b) => weight(b) - weight(a) || a.key.localeCompare(b.key));
  fs.writeFileSync("overlaps.json", JSON.stringify({ substances: Object.keys(S).length, drawings: report.length, settings: { FS, STROKE, PEN }, bad, all: report }, null, 1));

  const sum = t => bad.reduce((s, r) => s + r[t], 0);
  console.log(`Веществ: ${Object.keys(S).length}, рисунков: ${report.length}; с найденными накладками: ${bad.length} рисунков (${new Set(bad.map(b => b.key)).size} веществ)`);
  console.log(`Линия заходит на букву: ${sum("letter")}; на знак заряда: ${sum("charge")}; скобка на букву: ${sum("bracket")}; ` +
    `подписи друг на друге: ${sum("label")}; цикл через букву: ${sum("ring")}; обрезано краем: ${sum("clip")}`);
  console.log("\n  #  всего буква заряд скобка подп цикл край  вид   вещество");
  bad.forEach((r, i) => console.log(String(i + 1).padStart(3), String(r.total).padStart(5), String(r.letter).padStart(5),
    String(r.charge).padStart(5), String(r.bracket).padStart(6), String(r.label).padStart(4), String(r.ring).padStart(4),
    String(r.clip).padStart(4), "  " + (r.view === "x" ? "разв" : "скел"), "  " + r.key));
}
if (require.main === module) main();
module.exports = { parseDrawing, checkDrawing, textWidth, loadStructures };
