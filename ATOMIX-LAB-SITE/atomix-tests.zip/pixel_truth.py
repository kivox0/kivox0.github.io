"""
ATOMIX LAB · эталонная проверка по пикселям (для оценки геометрического скрипта).
Запуск: python3 pixel_truth.py [structures.json] [pixel_truth.json] [только_ключи.json]
Каждый рисунок отрисовывается в Chromium дважды при увеличении ×4:
  1) только подписи (линии прозрачные), 2) только линии (подписи прозрачные).
Пиксели, тёмные на обоих снимках, — это места, где линия реально лежит на
букве или знаке. Результат: pixel_truth.json {"ключ/вид": число пикселей}.
"""
import json, io, sys
import numpy as np
from PIL import Image
from playwright.sync_api import sync_playwright

SCALE = 4
SRC = sys.argv[1] if len(sys.argv) > 1 else "structures.json"
OUT = sys.argv[2] if len(sys.argv) > 2 else "pixel_truth.json"
ONLY = set(json.load(open(sys.argv[3]))) if len(sys.argv) > 3 else None
S = json.load(open(SRC, encoding="utf-8"))
CSS = """body{margin:0;background:#fff}
.mol{display:block;height:auto;color:#000;fill:#000}
.mol path,.mol circle{fill:none;stroke:#000;stroke-width:1.2;stroke-linecap:round;stroke-linejoin:round}
.mol text{font:7pt Arial,Helvetica,sans-serif}.mol .nidx{font-style:italic}
.mol tspan{fill:#000}
body.notext .mol text, body.notext .mol tspan{fill:transparent}
body.nolines .mol path, body.nolines .mol circle{stroke:transparent}"""

def mask(pg, cls):
    pg.evaluate(f"document.body.className = '{cls}'")
    png = pg.locator("svg").screenshot()
    a = np.asarray(Image.open(io.BytesIO(png)).convert("L"))
    return a < 128

def main():
    out = {}
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page()
        for key in S:
            for view in ("x", "s"):
                g = S[key].get(view)
                if not g or (ONLY is not None and f"{key}/{view}" not in ONLY): continue
                w, h, body = g
                pg.set_content(f'<!doctype html><meta charset="utf-8"><style>{CSS}</style>'
                               f'<svg class="mol" viewBox="0 0 {w} {h}" style="width:{w*SCALE}px">{body}</svg>')
                t = mask(pg, "nolines"); l = mask(pg, "notext")
                out[f"{key}/{view}"] = int((t & l).sum())
        b.close()
    json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
    vals = sorted(out.values(), reverse=True)
    print("рисунков:", len(out), "с перекрытием >0 px:", sum(v > 0 for v in vals), "топ-15:", vals[:15])

main()
