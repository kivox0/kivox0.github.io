"""
ATOMIX LAB · картинки «было / стало» для исправленных рисунков.
Запуск: python3 before_after.py   (нужны structures.json, structures_fixed.json, fix_report.json)
Картинки: before_after/NN_<вещество>_<вид>.png
"""
import json, re, html, pathlib
from playwright.sync_api import sync_playwright

A = json.load(open("structures.json", encoding="utf-8"))
B = json.load(open("structures_fixed.json", encoding="utf-8"))
rows = json.load(open("fix_report.json", encoding="utf-8"))
out = pathlib.Path("before_after"); out.mkdir(exist_ok=True)

CSS = """body{margin:0;background:#fff;font-family:Arial,Helvetica,sans-serif;color:#12161d}
.card{display:inline-block;padding:14px 18px}.title{font:600 14px Arial;margin:0 0 10px}
.row{display:flex;gap:28px}.pane{border:1px solid #dce0e7;border-radius:8px;padding:10px}
.cap{font:12px Arial;color:#637082;margin-top:6px}
.mol{display:block;height:auto;color:#12161d;fill:currentColor}
.mol path,.mol circle{fill:none;stroke:currentColor;stroke-width:1.2;stroke-linecap:round;stroke-linejoin:round}
.mol text{font:7pt Arial,Helvetica,sans-serif}.mol .nidx{font-style:italic}
.mol .o{fill:#c4321f}.mol .n{fill:#2446d8}.mol .x{fill:#1d7a49}"""

def svg(g, scale):
    w, h, body = g
    return f'<svg class="mol" viewBox="0 0 {w} {h}" style="width:{w*scale}px">{body}</svg>'

with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(device_scale_factor=2)
    for i, r in enumerate(rows, 1):
        k, v = r["key"], r["view"]
        scale = max(3.0, min(5.0, 380 / A[k][v][0]))
        pg.set_content(f'<!doctype html><meta charset="utf-8"><style>{CSS}</style><div class="card" id="c">'
                       f'<p class="title">{html.escape(k)} · {"развёрнутая" if v == "x" else "скелетная"}</p><div class="row">'
                       f'<div class="pane">{svg(A[k][v], scale)}<div class="cap">было</div></div>'
                       f'<div class="pane">{svg(B[k][v], scale)}<div class="cap">стало</div></div></div></div>')
        name = re.sub(r"[^\w\-\[\]()^+·]", "_", k)
        pg.locator("#c").screenshot(path=str(out / f"{i:03d}_{name}_{v}.png"))
    b.close()
print("готово:", len(rows), "картинок в", out)
