"""
ATOMIX LAB · Тест 1: XSS через поля ввода.
Запуск: python3 xss_test.py page.html
Открывает страницу в настоящем Chromium (Playwright), по очереди вписывает
вредоносные строки в поле уравнения (#eq-input) и в поиск по таблице (#q)
и проверяет, не выполнилось ли что-то и не появилось ли в DOM настоящих тегов.
"""
import json, sys, pathlib
from playwright.sync_api import sync_playwright

PAGE = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "page.html").resolve().as_uri()

PAYLOADS = [
    '<img src=x onerror=alert(1)>',
    '<script>alert(1)</script>',
    '"><svg onload=alert(1)>',
    'javascript:alert(1)',
    '{{7*7}}',
    '${alert(1)}',
    "'\"><img src=x onerror=alert(1)>",
    '`"\'><svg/onload=alert(1)>',
    '" onmouseover="alert(1)" x="',
    "H2O' onfocus='alert(1)' autofocus='",
    '</textarea><iframe src="javascript:alert(1)">',
    '&lt;img src=x onerror=alert(1)&gt;',
    '<details open ontoggle=alert(1)>',
    '<math><mtext><table><mglyph><style><img src=x onerror=alert(1)>',
    # смешанные: начало уравнения правильное, чтобы ввод прошёл глубже в парсер
    'H2 + O2 = <img src=x onerror=alert(1)>',
    'вода<img src=x onerror=alert(1)> = H2O',        # ветка «написано название / русские буквы»
    'Nа<svg onload=alert(1)>+ = NaCl',               # кириллическая «а» + заряд
    'Zn + HCl<script>alert(1)</script>',              # ветка «только исходные вещества»
    'Ba2+ + SO4"><img src=x onerror=alert(1)>2- = BaSO4',  # ионная ветка
    # со стрелкой: знак «=» внутри тега уже не считается знаком реакции, строка доходит до вывода
    'H2 → <img src=x onerror=alert(1)>',
    'CH4 → "><svg onload=alert(1)>',
    "NaCl → '><iframe src=javascript:alert(1)>",
]

# селектор «опасных» элементов, которых на странице быть не должно
DANGER_JS = """
() => {
  const out = [];
  document.querySelectorAll('*').forEach(el => {
    for (const a of el.attributes) {
      if (/^on/i.test(a.name)) out.push(el.tagName + '[' + a.name + ']');
      if (/^\\s*javascript:/i.test(a.value) && /^(href|src|action|formaction)$/i.test(a.name)) out.push(el.tagName + '[' + a.name + '=javascript:]');
    }
  });
  document.querySelectorAll('img[src="x"], iframe, details[ontoggle], mglyph').forEach(el => out.push('NEW ' + el.tagName));
  out.push('scripts=' + document.scripts.length);
  return out;
}
"""

def main():
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        # внешние запросы (Google Fonts) не нужны для теста
        page.route("**/*", lambda r: r.abort() if not r.request.url.startswith("file:") else r.continue_())
        dialogs, console_err, page_err = [], [], []
        page.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
        page.on("console", lambda m: m.type == "error" and console_err.append(m.text))
        page.on("pageerror", lambda e: page_err.append(str(e)))
        page.goto(PAGE, wait_until="domcontentloaded")
        page.wait_for_timeout(300)
        baseline = page.evaluate(DANGER_JS)
        base_err = list(console_err)
        page.click("#eq-open")

        def snapshot():
            d = page.evaluate(DANGER_JS)
            return [x for x in d if x not in baseline]

        for i, pl in enumerate(PAYLOADS, 1):
            row = {"n": i, "payload": pl}
            n_dlg, n_con, n_pe = len(dialogs), len(console_err), len(page_err)

            # --- поле уравнения: печатаем по символу (каждый символ запускает автодополнение и живую подсказку)
            page.fill("#eq-input", "")
            page.click("#eq-input")
            page.keyboard.type(pl, delay=0)
            sugg_open = page.is_visible("#eq-sugg")
            preview_html = page.inner_html("#eq-preview")
            page.keyboard.press("Escape")
            page.click("#eq-check")
            page.wait_for_timeout(50)
            res_html = page.inner_html("#eq-result-manual")
            res_text = page.inner_text("#eq-result-manual")
            # нажимаем все кнопки «Исправить / Заменить», если они появились
            clicked = 0
            for sel in ["#eq-preview [data-fix-quiet]", "#eq-result-manual [data-fix]", "#eq-result-manual [data-replace-from]"]:
                if page.locator(sel).count():
                    page.locator(sel).first.click(); clicked += 1; page.wait_for_timeout(50)
            # переключаем язык туда и обратно — результат перерисовывается заново
            page.click("#lang-btn"); page.wait_for_timeout(50); page.click("#lang-btn"); page.wait_for_timeout(50)
            # наводим мышь на результат (для onmouseover)
            page.hover("#eq-result-manual")
            row["eq_danger"] = snapshot()
            row["eq_reflected"] = "&lt;" in res_html or "&gt;" in res_html
            row["eq_escaped_lt"] = ("<" not in pl) or ("&lt;" in res_html) or not row["eq_reflected"]
            row["eq_reflected_as_text"] = any(ch in res_text for ch in "<>\"'`") if any(ch in pl for ch in "<>\"'`") else None
            row["eq_preview_has_tag"] = "<img" in preview_html or "<svg" in preview_html or "<script" in preview_html
            row["eq_fix_buttons_clicked"] = clicked
            row["eq_sugg_seen"] = sugg_open

            # --- поиск по таблице (#q)
            page.fill("#q", pl)
            page.keyboard.press("Enter")
            page.wait_for_timeout(50)
            qerr_html = page.inner_html("#q-err")
            row["q_err_html"] = qerr_html[:160]
            row["q_danger"] = snapshot()
            page.fill("#q", "")
            page.dispatch_event("#q", "input")

            row["dialogs"] = dialogs[n_dlg:]
            row["console_errors"] = console_err[n_con:]
            row["page_errors"] = page_err[n_pe:]
            row["fired"] = bool(row["dialogs"] or row["eq_danger"] or row["q_danger"])
            results.append(row)
        browser.close()
    json.dump({"baseline_console_errors": base_err, "results": results}, open("xss_results.json", "w"), ensure_ascii=False, indent=1)
    for r in results:
        print(f'{r["n"]:2} fired={r["fired"]!s:5} dlg={len(r["dialogs"])} conErr={len(r["console_errors"])} pageErr={len(r["page_errors"])} '
              f'refl={r["eq_reflected"]!s:5} esc={r["eq_escaped_lt"]} fixClicks={r["eq_fix_buttons_clicked"]} sugg={r["eq_sugg_seen"]} | {r["payload"]}')

main()
